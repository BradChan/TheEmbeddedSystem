// Copyright (c) HiiBot. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

#include "BlueFi.h"

BlueFi::BlueFi():__isInited(0) {
}

void BlueFi::begin(bool LCDEnable, bool SerialEnable) {	
	//! Correct init once
	if (__isInited) return;
	else __isInited = true;
	// other initialization code
}

BlueFi bluefi;

