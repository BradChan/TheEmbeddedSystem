//! Copyright (c) HiiBot. All rights reserved.
//! Licensed under the MIT license. See LICENSE file in the project root for full license information.

#ifndef ___BLUEFI_H_
#define ___BLUEFI_H_

#include "utility/BlueFi_LEDs.h"
#include "utility/BlueFi_Button2.h"


class BlueFi {

 public:
    BlueFi();
    void begin(bool LCDEnable=true, bool SerialEnable=true);
    LED redLED = LED(LED_RED);
    LED whiteLED = LED(LED_WHITE);
    Button2 aButton = Button2(PIN_BUTTON1, INPUT_PULLDOWN, 50);
    Button2 bButton = Button2(PIN_BUTTON2, INPUT_PULLDOWN, 50);

 private:
    bool __isInited;
};

extern BlueFi bluefi;

#endif // ___BLUEFI_H_