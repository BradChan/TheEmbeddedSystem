//! Copyright (c) HiiBot. All rights reserved.
//! Licensed under the MIT license. See LICENSE file in the project root for full license information.

#ifndef ___BLUEFI_LEDS_H_
#define ___BLUEFI_LEDS_H_

#include <Arduino.h>

class LED {

  public:

    LED(uint8_t pin);
    uint8_t getAttachPin(void);
    void on(void);
    void off(void);
    void toggle(void);
    bool state(void);

 private:
    bool __isInited;
    bool __state;
    uint8_t __pin;
};

#endif // ___BLUEFI_LEDS_H_