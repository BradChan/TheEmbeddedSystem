//! Copyright (c) HiiBot. All rights reserved.
//! Licensed under the MIT license. See LICENSE file in the project root for full license information.

#ifndef ___BLUEFI_H_
#define ___BLUEFI_H_

#include "utility/BlueFi_LEDs.h"

class BlueFi {

 public:
    BlueFi();
    void begin(bool LCDEnable=true, bool SerialEnable=true);
    LED redLED = LED(LED_RED);
    LED whiteLED = LED(LED_WHITE);

 private:
    bool __isInited;
};

extern BlueFi bluefi;

#endif // ___BLUEFI_H_