// Copyright (c) HiiBot. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

#include "BlueFi_LEDs.h"

LED::LED(uint8_t pin) {
    __isInited = 1;
    __state = 0;
    __pin = pin;
    pinMode(__pin, OUTPUT);
    digitalWrite(__pin, __state);
}

uint8_t LED::getAttachPin(void) {
    return __pin;
}

void LED::on(void) {
    __state = 1;
    digitalWrite(__pin, __state);
}

void LED::off(void) {
    __state = 0;
    digitalWrite(__pin, __state);
}

void LED::toggle(void) {
    __state = (__state)?0:1;
    digitalWrite(__pin, __state);
}

bool LED::state(void) {
	return __state;
}

void LED::bright(uint16_t bv) {
    analogWrite(__pin, bv);
}
