//! Copyright (c) HiiBot. All rights reserved.
//! Licensed under the MIT license. See LICENSE file in the project root for full license information.

#ifndef ___BLUEFI_H_
#define ___BLUEFI_H_

#include <Arduino.h>
//#include <Wire.h>

#include "utility/BlueFi_LEDs.h"
#include "utility/BlueFi_Button2.h"
#include "utility/BlueFi_Speak.h"
#include "utility/PDM_mic/PDM_mic.h"
#include "utility/BlueFi_LSM6DS3.h"
#include "utility/BlueFi_SHT30.h"


class BlueFi {

 public:
    BlueFi();
    void begin(bool LCDEnable=true, bool SerialEnable=true);
    LED redLED = LED(LED_RED);
    LED whiteLED = LED(LED_WHITE);
    Button2 aButton = Button2(PIN_BUTTON1, INPUT_PULLDOWN, 50);
    Button2 bButton = Button2(PIN_BUTTON2, INPUT_PULLDOWN, 50);
    //Speak speak = Speak();
    LSM6DS3 imu = LSM6DS3(Wire1); // LSM6DS3(IMU) sensor
    SHT30 rht = SHT30(Wire1); // SHT30(RH&T) sensor

 private:
    bool __isInited;
};

extern BlueFi bluefi;

#endif // ___BLUEFI_H_