//! Copyright (c) HiiBot. All rights reserved.
//! Licensed under the MIT license. See LICENSE file in the project root for full license information.
//! Arduino library for Sensirion temperature and humidity sensors SHT30.

#ifndef __BLUEFI_SHT30_H_
#define __BLUEFI_SHT30_H_

#include <Arduino.h>
#include <Wire.h>
#include <math.h> 

#define DefaultSlaveAddress_SHT30 0x44
//#define DefaultSlaveAddress_SHT30 0x45
#define SHT31_MEAS_HIGHREP_STRETCH  0x2C06 /**< Measurement High Repeatability with Clock Stretch Enabled */
#define SHT31_MEAS_MEDREP_STRETCH   0x2C0D /**< Measurement Medium Repeatability with Clock Stretch Enabled */
#define SHT31_MEAS_LOWREP_STRETCH   0x2C10 /**< Measurement Low Repeatability with Clock Stretch Enabled*/
#define SHT31_MEAS_HIGHREP    0x2400 /**< Measurement High Repeatability with Clock Stretch Disabled */
#define SHT31_MEAS_MEDREP     0x240B /**< Measurement Medium Repeatability with Clock Stretch Disabled */
#define SHT31_MEAS_LOWREP     0x2416 /**< Measurement Low Repeatability with Clock Stretch Disabled */
#define SHT31_READSTATUS      0xF32D   /**< Read Out of Status Register */
#define SHT31_CLEARSTATUS     0x3041  /**< Clear Status */
#define SHT31_SOFTRESET       0x30A2    /**< Soft Reset */
#define SHT31_HEATEREN        0x306D     /**< Heater Enable */
#define SHT31_HEATERDIS       0x3066    /**< Heater Disable */
#define SHT31_REG_HEATER_BIT  0x0d /**< Status Register Heater Bit */
#define msONGOING  50  /* >=20ms */

class SHT30 {

  public:
    SHT30(TwoWire& wire, uint8_t slaveAddress=DefaultSlaveAddress_SHT30);
    virtual ~SHT30(){};
    bool begin(void);
    uint16_t readStatus(void);
    void reset(void);
    void heater(bool on); // true: on, false: off
    bool isHeaterEnabled(void); 
    void RHT_FSM(void);
    bool isReady;
    float temperature, humidity;

  private:
    bool writeCommand(uint16_t command);
    bool readRegisters(uint8_t *buf, size_t len);
    bool writeRegisters(uint8_t *buf, size_t len);

    TwoWire* __wire;
    uint8_t __Address;
    uint32_t __startMillis;

    enum rht_FSM
    {
      IDLE = 0,
      ONGOING,
      READY
    } __rht_FSM;

};

#endif // __BLUEFI_SHT30_H_
