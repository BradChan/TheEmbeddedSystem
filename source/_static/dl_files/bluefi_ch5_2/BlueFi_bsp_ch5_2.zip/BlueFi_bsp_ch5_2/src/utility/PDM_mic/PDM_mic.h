// Copyright (c) HiiBot. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

#ifndef __PDM_MIC_H__
#define __PDM_MIC_H__

#include <Arduino.h>
#include "dbuf/PDMDoubleBuffer.h"

class PDMClass {

public:
  PDMClass(int dinPin=22, int clkPin=21, int pwrPin=-1);
  virtual ~PDMClass();
  int begin(int channels=1, long sampleRate=16000);
  void end();
  virtual int available();
  virtual int read(void* buffer, size_t size);
  void onReceive(void(*)(void));
  void setGain(int gain=20);
  void setBufferSize(int bufferSize);
  void IrqHandler();

private:
  int _dinPin;
  int _clkPin;
  int _pwrPin;
  int _channels;
  PDMDoubleBuffer _doubleBuffer;
  void (*_onReceive)(void);
};

extern PDMClass mic;

#endif // __PDM_MIC_H__
