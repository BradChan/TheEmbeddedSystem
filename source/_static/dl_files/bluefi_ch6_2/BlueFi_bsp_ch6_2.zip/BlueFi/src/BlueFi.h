//! Copyright (c) HiiBot. All rights reserved.
//! Licensed under the MIT license. See LICENSE file in the project root for full license information.

#ifndef ___BLUEFI_H_
#define ___BLUEFI_H_

#include <Arduino.h>
//#include <Wire.h>

#define BLUEFI_BLACK    0x000000
#define BLUEFI_WHITE    0x7F7F7F
#define BLUEFI_RED      0xFF0000
#define BLUEFI_ORANGE   0xFF9300
#define BLUEFI_YELLOW   0xFFFA00
#define BLUEFI_GREEN    0x00FF00
#define BLUEFI_CYAN     0x00FDFF
#define BLUEFI_BLUE     0x0000FF
#define BLUEFI_VIOLET   0x9437FF
#define BLUEFI_MAGENTA  0xFF40FF


#include "utility/BlueFi_LEDs.h"
#include "utility/BlueFi_Button2.h"
#include "utility/BlueFi_NeoPixel.h"
#include "utility/BlueFi_Speak.h"
#include "utility/PDM_mic/PDM_mic.h"
#include "utility/BlueFi_LSM6DS3.h"
#include "utility/BlueFi_SHT30.h"
#include <BlueFi_TFT_eSPI.h> 


class BlueFi {

 public:
    const uint16_t NumPixels = 5;
    BlueFi();
    void begin(bool LCDEnable=true, bool SerialEnable=true);

    TFT_eSPI Lcd = TFT_eSPI();
    LED redLED = LED(LED_RED);
    LED whiteLED = LED(LED_WHITE);
    Button2 aButton = Button2(PIN_BUTTON1, INPUT_PULLDOWN, 50);
    Button2 bButton = Button2(PIN_BUTTON2, INPUT_PULLDOWN, 50);
    BlueFi_NeoPixel pixels = BlueFi_NeoPixel(NumPixels, 18, NEO_GRB+NEO_KHZ800);
    Speak speak = Speak();
    LSM6DS3 imu = LSM6DS3(Wire1); // LSM6DS3(IMU) sensor
    SHT30 rht = SHT30(Wire1); // SHT30(RH&T) sensor

 private:
    bool __isInited;
};

extern BlueFi bluefi;

#endif // ___BLUEFI_H_