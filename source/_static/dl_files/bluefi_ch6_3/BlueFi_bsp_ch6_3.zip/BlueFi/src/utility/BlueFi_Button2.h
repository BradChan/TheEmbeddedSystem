/////////////////////////////////////////////////////////////////
/*
  Button2.cpp - Arduino Library to simplify working with buttons.
  Created by Lennart Hennigs, October 28, 2017.
*/
/////////////////////////////////////////////////////////////////
#pragma once

#ifndef __BLUEFI_BUTTON2_H_
#define __BLUEFI_BUTTON2_H_

/////////////////////////////////////////////////////////////////

#include <Arduino.h>

/////////////////////////////////////////////////////////////////

#define DEBOUNCE_MS       50
#define LONGCLICK_MS    2000
#define DOUBLECLICK_MS   400

#define SINGLE_CLICK       1
#define DOUBLE_CLICK       2
#define TRIPLE_CLICK       3
#define LONG_CLICK         4

/////////////////////////////////////////////////////////////////

class Button2 {
  private:
    bool prev_state;
    bool state = HIGH;
    bool pressed_triggered = false;
    bool longclick_detected = false;
    uint8_t pin;
    uint8_t click_count = 0;
    uint8_t last_click_type = 0;
    uint32_t click_ms;
    uint32_t down_ms;
    uint32_t debounce_time_ms;
    uint32_t down_time_ms = 0;
        
    typedef void (*CallbackFunction) (Button2&);

    CallbackFunction pressed_cb = NULL;
    CallbackFunction released_cb = NULL;
    CallbackFunction change_cb = NULL;
    CallbackFunction tap_cb = NULL;
    CallbackFunction click_cb = NULL;
    CallbackFunction long_cb = NULL;
    CallbackFunction double_cb = NULL;
    CallbackFunction triple_cb = NULL;
    
  public:
    Button2(){pin = -1;}
    Button2(uint8_t attachTo, uint8_t buttonMode = INPUT_PULLDOWN, uint32_t debounceTimeout = DEBOUNCE_MS);
    void setDebounceTime(uint32_t ms);
    
    void setChangedHandler(CallbackFunction f);
    void setPressedHandler(CallbackFunction f);
    void setReleasedHandler(CallbackFunction f);
    void setClickHandler(CallbackFunction f);
    void setTapHandler(CallbackFunction f);
    void setLongClickHandler(CallbackFunction f);
    void setDoubleClickHandler(CallbackFunction f);
    void setTripleClickHandler(CallbackFunction f);

    uint32_t wasPressedFor();
    boolean isPressed();

    uint8_t getNumberOfClicks();
    uint8_t getClickType();
    uint8_t getAttachPin(){return pin;}
    bool operator==(Button2 &rhs);

    void loop();
};
/////////////////////////////////////////////////////////////////
#endif // __BLUEFI_BUTTON2_H_
/////////////////////////////////////////////////////////////////
