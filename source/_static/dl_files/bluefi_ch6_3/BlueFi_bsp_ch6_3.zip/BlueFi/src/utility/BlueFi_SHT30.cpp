//! Copyright (c) HiiBot. All rights reserved.
//! Licensed under the MIT license. See LICENSE file in the project root for full license information.
//! Arduino library for Sensirion temperature and humidity sensors SHT30.

#include "BlueFi_SHT30.h"

SHT30::SHT30(TwoWire& wire, uint8_t slaveAddress):
  __wire(&wire),
  __Address(slaveAddress) {
  humidity = NAN;
  temperature = NAN;
  isReady = false;
  __rht_FSM = IDLE;
}

bool SHT30::begin(void) {
  __wire->begin();
  reset();
  return readStatus() != 0xFFFF; // check read-back operation
}

static uint8_t crc8(const uint8_t *data, int len) {
  /*
   * CRC-8 formula from page 14 of SHT3x spec pdf
   * Test data 0xBE, 0xEF should yield 0x92
   * Initialization data 0xFF
   * Polynomial 0x31 (x8 + x5 +x4 +1)
   * Final XOR 0x00
   */
  const uint8_t  POLYNOMIAL(0x31);
  uint8_t crc(0xFF);
  for (int j=len; j; --j) {
    crc ^= *data++;
    for (int i=8; i; --i)
      crc = (crc&0x80)? (crc<<1)^POLYNOMIAL : (crc<<1);
  }
  return crc;
}

uint16_t SHT30::readStatus(void) {
  uint8_t data[3];
  writeCommand(SHT31_READSTATUS);
  readRegisters(data, 3);
  uint16_t stat = data[0];
  stat <<= 8;
  stat |= data[1];
  return stat; 
}

void SHT30::reset(void) {
  writeCommand(SHT31_SOFTRESET);
  delay(10);
}

void SHT30::heater(bool on) {
  if (on)
    writeCommand(SHT31_HEATEREN);
  else
    writeCommand(SHT31_HEATERDIS);
  delay(1);
}

bool SHT30::isHeaterEnabled(void) {
  uint16_t regValue = readStatus();
  return (regValue&SHT31_REG_HEATER_BIT);
}

/*  the Finite State Machine for starting measure and readout data
 *                    |---------------------------------|
 *  initialize  -->  IDLE  -->  ONGOING  -->  READY  --->
 *                    -->  start   -->   delay  -->  readout ->
 */
void SHT30::RHT_FSM(void) {
  uint8_t _readbuffer[6]; // TTCHHC
  int32_t _stemp;
  uint32_t _shum;
  switch (__rht_FSM) {
    case IDLE:
      writeCommand(SHT31_MEAS_HIGHREP); // start
      __startMillis = millis();
      __rht_FSM = ONGOING;
      break;
    case ONGOING:
      if ( (millis()-__startMillis) >= msONGOING ){  // check delay
        __rht_FSM = READY;
      }
      break;
    case READY:
      readRegisters(_readbuffer, sizeof(_readbuffer));
      if ( (_readbuffer[2]==crc8(_readbuffer, 2)) && (_readbuffer[5] == crc8(_readbuffer + 3, 2)) ) {
        _stemp = (int32_t)(((uint32_t)_readbuffer[0] << 8) | _readbuffer[1]);
        // simplified (65536 instead of 65535) integer version of:
        // temperature = (_stemp * 175.0f) / 65535.0f - 45.0f;
        _stemp = ((4375 * _stemp) >> 14) - 4500;
        temperature = (float)_stemp / 100.0f;
        _shum = ((uint32_t)_readbuffer[3] << 8) | _readbuffer[4];
        // simplified (65536 instead of 65535) integer version of:
        // humidity = (_shum * 100.0f) / 65535.0f;
        _shum = (625 * _shum) >> 12;
        humidity = (float)_shum / 100.0f;        
      }
      isReady = true;
      __rht_FSM = IDLE;
      break;
    default:
      __rht_FSM = IDLE;
      break;
  }
}

bool SHT30::writeCommand(uint16_t command) {
  uint8_t cmd[2];
  cmd[0] = command >> 8;
  cmd[1] = command & 0xFF;
  return writeRegisters(cmd, 2);
}

bool SHT30::readRegisters(uint8_t *buf, size_t len)
{
  //__wire->beginTransmission(__Address);
  if (__wire->requestFrom(__Address, len) != len)
    return 0;
  for (size_t i=0; i<len; i++)
    buf[i] = __wire->read();
  return 1;
}

bool SHT30::writeRegisters(uint8_t *buf, size_t len) {
  __wire->beginTransmission(__Address);
  if (__wire->write(buf, len) != len) 
    return 0;
  if (__wire->endTransmission() != 0)
    return 0;
  return 1;
}
