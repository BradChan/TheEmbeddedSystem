//! Copyright (c) HiiBot. All rights reserved.
//! Licensed under the MIT license. See LICENSE file in the project root for full license information.

#ifndef ___BLUEFI_SPEAK_H_
#define ___BLUEFI_SPEAK_H_

#include <Arduino.h>
#include "PitchsFrequency.h"  // the frequency of pitch

class Speak {

  public:
    Speak();
    void begin(void);
    void playTone(uint16_t frequency, uint32_t duration=0);
    void stop(void);
    void playMIDI(uint8_t midi, uint8_t beat=0);
    uint8_t setBPM(uint8_t bpm);
    uint8_t changeBPMwith(int8_t bpm);
    void enableAudio(bool en=true);

 private:
    uint8_t __bpm;
    uint8_t __pinAPW;   // enable audio
    uint8_t __pinAudio; // audio signal
    

};

#endif // ___BLUEFI_SPEAK_H_