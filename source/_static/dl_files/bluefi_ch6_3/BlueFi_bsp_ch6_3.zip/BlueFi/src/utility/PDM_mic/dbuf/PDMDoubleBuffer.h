//! Copyright (c) HiiBot. All rights reserved.
//! Licensed under the MIT license. See LICENSE file in the project root for full license information.

#ifndef __PDM_DOUBLE_BUFFER_H__
#define __PDM_DOUBLE_BUFFER_H__

#include <stddef.h>
#include <stdint.h>

#define DEFAULT_PDM_BUFFER_SIZE 512

class PDMDoubleBuffer {

public:
  PDMDoubleBuffer();
  virtual ~PDMDoubleBuffer();
  void setSize(int size);
  void reset();
  size_t availableForWrite();
  size_t write(const void *buffer, size_t size);
  size_t read(void *buffer, size_t size);
  size_t peek(void *buffer, size_t size);
  void* data();
  size_t available();
  void swap(int length = 0);

private:
  uint8_t* _buffer[2];
  int _size;
  volatile int _length[2];
  volatile int _readOffset[2];
  volatile int _index; 
};

#endif // __PDM_DOUBLE_BUFFER_H__
