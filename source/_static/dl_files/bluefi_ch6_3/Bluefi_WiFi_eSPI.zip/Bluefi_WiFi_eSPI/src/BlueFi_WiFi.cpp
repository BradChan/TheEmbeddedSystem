#include "BlueFi_WiFi.h"
#include "secrets_wifi.h" // SECRET_SSID, and SECRET_PASS of your WiFi AP

#define EnableSerialPrint 1

char ssid[] = SECRET_SSID; // see "secrets_wifi.h"
char pass[] = SECRET_PASS; // see "secrets_wifi.h"

// STA模式, 连接到指定的SECRET_SSID, and SECRET_PASS
bool connectWiFi(bool blocking) {
	uint8_t trycnt = 3;
	uint8_t status = WL_IDLE_STATUS;
  	// check for the WiFi Coprocessor
	#if EnableSerialPrint
	Serial.println("Check WiFi Coprocessor");
	#endif
	while (WiFi.status() == WL_NO_MODULE) {
		#if EnableSerialPrint
		Serial.println("Communication with WiFi Coprocessor failed!");
		#endif
		delay(1000);
		if (!blocking) {
			if (trycnt>=1)
				trycnt--;
			else 
				return false;
		}
	}
	// check firmware version of WiFi Coprocessor
	String fv = WiFi.firmwareVersion();
	#if EnableSerialPrint
	Serial.print("WiFi Coprocessor firmware: "); Serial.println(fv);
	#endif

	// attempt to connect to WiFi network:
	#if EnableSerialPrint
	Serial.print("Attempting to connect to AP with SSID: "); Serial.println(ssid);
	#endif
	// Connect to WPA/WPA2 network. Change this line if using open or WEP network (see WiFi.begin()):
	trycnt = 20;
	do {
		#if EnableSerialPrint
		Serial.print(".");
		#endif
		status = WiFi.begin(ssid, pass);
		delay(500);     // wait until connection is ready!
		if (!blocking) {
			if (trycnt>=1)
				trycnt--;
			else 
				return false;
		}
	} while (status != WL_CONNECTED);
	#if EnableSerialPrint
	Serial.println(" ");
	Serial.println("Connected to wifi");
	// print the SSID of the network we are attached to:
	Serial.print("SSID: ");
	Serial.println(WiFi.SSID());
	// print BlueFi's IP address:
	IPAddress ip = WiFi.localIP();
	Serial.print("IP Address: ");
	Serial.println(ip);
	// print the received signal strength:
	long rssi = WiFi.RSSI();
	Serial.print("signal strength (RSSI):");
	Serial.print(rssi);
	Serial.println(" dBm");
	#endif
	return true;
}

bool reconnectWiFi(bool blocking) {
	uint8_t status = WL_IDLE_STATUS;
	status = WiFi.status();
	if (status==WL_CONNECTED)
		return true;
	else
		return connectWiFi(blocking);
}

bool disconnectWiFi(void) {
	uint8_t status = WL_IDLE_STATUS;
	status = WiFi.status();
	if (status==WL_DISCONNECTED) 
		return true;
	else {
		status = WiFi.disconnect();
		return (status==WL_DISCONNECTED);
	}
}

