
#ifndef __BlueFi_WiFi_h__
#define __BlueFi_WiFi_h__

#include "WiFi.h"

bool connectWiFi(bool blocking=true);
bool reconnectWiFi(bool blocking=false);
bool disconnectWiFi(void);

#endif
