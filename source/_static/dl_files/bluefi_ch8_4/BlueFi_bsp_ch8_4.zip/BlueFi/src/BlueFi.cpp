// Copyright (c) HiiBot. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

#include "BlueFi.h"

BlueFi::BlueFi():__isInited(0) {
}

void BlueFi::begin(bool LCDEnable, bool SerialEnable) {	
	//! Correct init once
	if (__isInited) return;
	else __isInited = true;

	// initialization code for red-LED and white-LED
	redLED.off();
	whiteLED.off();
	speak.begin();  // set all pin to LOW

	// NeoPixel
	pixels.begin();
	pixels.setBrightness(6);
	pixels.fill(BLUEFI_BLACK);
	pixels.show();
	
	uint32_t colors[] = {BLUEFI_RED, BLUEFI_ORANGE, BLUEFI_GREEN, BLUEFI_CYAN, BLUEFI_BLUE};
	for (uint8_t i=0; i<5; i++) {
		pixels.setPixelColor(i, colors[i]);
	}
	pixels.show();

	if (SerialEnable) {
		Serial.begin(115200);
	}
	
	if (LCDEnable) {
		Lcd.init();
		Lcd.setRotation(1);
		Lcd.fillScreen(TFT_BLACK); // clear screen
		Lcd.setCursor(6, 108, 4);
		Lcd.setTextColor(TFT_RED, TFT_BLACK);
		Lcd.print("BlueFi "); // red
		Lcd.setTextColor(TFT_GREEN, TFT_BLACK);
		Lcd.print(" with "); // green
		Lcd.setTextColor(TFT_BLUE, TFT_BLACK);
		Lcd.print(" Arduino\n"); // blue, "\n", to skip a line
		Lcd.setTextColor(TFT_WHITE, TFT_BLACK);
	}

	// RH&T sensor
	rht.begin();

	// IMU 
	imu.begin();

	pixels.fill(BLUEFI_BLACK);
	pixels.show();
}

BlueFi bluefi;

