//! Copyright (c) HiiBot. All rights reserved.
//! Licensed under the MIT license. See LICENSE file in the project root for full license information.
//! Arduino library for ST IMU sensorLSM6DS3.

#include "BlueFi_LSM6DS3.h"

LSM6DS3::LSM6DS3(TwoWire& wire, uint8_t slaveAddress) :
  __wire(&wire),
  __Address(slaveAddress) {
}

bool LSM6DS3::begin(void) {
    __wire->begin();
  if (readRegister(LSM6DS3_WHO_AM_I_REG) != 0x69) {
    end();
    return false;
  }
  //set the gyroscope control register to work at 104 Hz, 2000 dps and in bypass mode
  writeRegister(LSM6DS3_CTRL2_G, 0x4C);
  // Set the Accelerometer control register to work at 104 Hz, 4G,and in bypass mode and enable ODR/4
  // low pass filter(check figure9 of LSM6DS3's datasheet)
  writeRegister(LSM6DS3_CTRL1_XL, 0x4A);
  // set gyroscope power mode to high performance and bandwidth to 16 MHz
  writeRegister(LSM6DS3_CTRL7_G, 0x00);
  // Set the ODR config register to ODR/4
  writeRegister(LSM6DS3_CTRL8_XL, 0x09);
  return true;
}

void LSM6DS3::end() {
    writeRegister(LSM6DS3_CTRL2_G, 0x00);
    writeRegister(LSM6DS3_CTRL1_XL, 0x00);
    __wire->end();
}

bool LSM6DS3::readAcceleration(float& x, float& y, float& z) {
  int16_t data[3];
  if (!readRegisters(LSM6DS3_OUTX_L_XL, (uint8_t*)data, sizeof(data))) {
    x = NAN, y = NAN, z = NAN;
    return false;
  }
  x = data[0] * 4.0 / 32768.0;
  y = data[1] * 4.0 / 32768.0;
  z = data[2] * 4.0 / 32768.0;
  return true;
}

bool LSM6DS3::accelerationAvailable() {
  if (readRegister(LSM6DS3_STATUS_REG) & 0x01) {
    return true;
  }
  return false;
}

float LSM6DS3::accelerationSampleRate() {
  return 104.0F; // 104Hz
}

bool LSM6DS3::readGyroscope(float& x, float& y, float& z) {
  int16_t data[3];
  if (!readRegisters(LSM6DS3_OUTX_L_G, (uint8_t*)data, sizeof(data))) {
    x = NAN, y = NAN, z = NAN;
    return false;
  }
  x = data[0] * 2000.0 / 32768.0;
  y = data[1] * 2000.0 / 32768.0;
  z = data[2] * 2000.0 / 32768.0;
  return true;
}

bool LSM6DS3::gyroscopeAvailable() {
  if (readRegister(LSM6DS3_STATUS_REG) & 0x02) {
    return true;
  }
  return false;
}

float LSM6DS3::gyroscopeSampleRate() {
  return 104.0F;
}

int LSM6DS3::readRegister(uint8_t regAddr) {
  uint8_t value;
  if (readRegisters(regAddr, &value, sizeof(value)) != 1) {
    return -1;
  }
  
  return value;
}

int LSM6DS3::readRegisters(uint8_t regAddr, uint8_t* data, size_t length)
{
  __wire->beginTransmission(__Address);
  __wire->write(regAddr);
  if (__wire->endTransmission(false) != 0) {
    return -1;
  }
  if (__wire->requestFrom(__Address, length) != length) {
    return 0;
  }
  for (size_t i=0; i<length; i++) {
    *data++ = __wire->read();
  }
  return 1;
}

int LSM6DS3::writeRegister(uint8_t regAddr, uint8_t value) {
  __wire->beginTransmission(__Address);
  __wire->write(regAddr);
  __wire->write(value);
  if (__wire->endTransmission() != 0) {
    return 0;
  }
  return 1;
}

int LSM6DS3::writeRegisters(uint8_t regAddr, uint8_t* data, size_t length) {
  __wire->beginTransmission(__Address);
  __wire->write(regAddr);
  for (size_t i=0; i<length; i++) {
    __wire->write(*data++);
  }
  if (__wire->endTransmission() != 0) {
    return 0;
  }
  return 1;
}

