// Copyright (c) HiiBot. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

#include "BlueFi_Speak.h"

Speak::Speak() {
    __bpm = 120; // 120 (beats/minute), 500ms/beats
    __pinAPW = 45;    // enable audio
    __pinAudio = 46;  // audio signal
}

void Speak::begin(void) {
    pinMode(__pinAPW, OUTPUT);
    digitalWrite(__pinAPW, LOW);
    pinMode(__pinAudio, OUTPUT);
    digitalWrite(__pinAudio, HIGH);
}

void Speak::playTone(uint16_t frequency, uint32_t duration) {
    digitalWrite(__pinAPW, HIGH);
    tone(__pinAudio, frequency, duration);
}

void Speak::stop(void) {
    noTone(__pinAudio);
    digitalWrite(__pinAPW, LOW);
}

void Speak::playMIDI(uint8_t midi, uint8_t beat) {
    if ((midi == 0) && (beat == 0)) return;
    float t = 0.0F;
    if (beat != 0) {
        t = (60000.0F/(float)__bpm)/(float)beat;
    }
    if (midi >= 99) midi = 99;
    uint16_t f = tableMIDI2Tone[midi];
    digitalWrite(__pinAPW, HIGH);
    tone(__pinAudio, f, (uint32_t)t);
}

uint8_t Speak::setBPM(uint8_t bpm) {
    if (bpm <= 30) bpm = 30; // 30 beats per minute
    if (bpm >= 240) bpm = 240; // 240 beats per minute
    __bpm = bpm;
    return __bpm;
}

uint8_t Speak::changeBPMwith(int8_t bpm) {
    if (bpm > 0) __bpm += bpm;
    if (bpm < 0) __bpm -= abs(bpm);
    if (__bpm <= 30) __bpm = 30; 
    if (__bpm >= 240) __bpm = 240; 
    return __bpm;
}

void Speak::enableAudio(bool en) {
    digitalWrite(__pinAPW, en);
}
