//! Copyright (c) HiiBot. All rights reserved.
//! Licensed under the MIT license. See LICENSE file in the project root for full license information.

#ifndef ___ALGORITHM_FIFO_QUEUE_H_
#define ___ALGORITHM_FIFO_QUEUE_H_

const uint8_t sizeFIFO = 12;
typedef uint8_t typeElement;

typedef struct {
    // font: out queue pointer
    // rear: in queue pointer
    // count: available elements number
    // elements[sizeFIFO]: fifo queue (a array)
  uint8_t front, rear, count; 
  typeElement elements[sizeFIFO];
} typeFIFO;

/*
 *  initialize a FiFo Queue
 *  @param  typeFIFO* : the pointer to typeFIFO 
 *  example: 
 *      typeFIFO revFiFo;
 *      typeElement elem;
 *      fifiInit( &revFiFo ); // initialize the FiFo queue "revFiFo"
 */
void fifoInit(typeFIFO* fifo) {
   fifo->front=0; fifo->rear=0; fifo->count=0;
}

/*
 *  push a data iterm into FiFo Queue
 *  @param  typeFIFO* : the pointer to typeFIFO 
 *  @param  typeElement : a data iterm (typeElement)
 *  example: 
 *      typeFIFO revFiFo;
 *      typeElement elem;
 *      fifiInit( &revFiFo ); // initialize the FiFo queue "revFiFo"
 *      fifoIn( &revFiFo , (typeElement)100 ); // push 100 into FiFo queue
 */
bool fifoIn(typeFIFO* fifo, typeElement dat) { 
  if ( (fifo->front==fifo->rear) && (fifo->count==sizeFIFO) )
    return false; // FIFO queue is full!
  else {
    fifo->elements[fifo->rear] = dat; // push it to queue
    fifo->rear = (fifo->rear + 1) % sizeFIFO; // move the pointer
    fifo->count += 1; // queue number plus one
    return true;
  }
}

/*
 *  pop a data iterm from FiFo Queue
 *  @param  typeFIFO* : the pointer to typeFIFO 
 *  @param  typeElement* : the pointer to a data iterm (typeElement)
 *  example: 
 *      typeFIFO revFiFo;
 *      typeElement elem=0;
 *      fifiInit( &revFiFo ); // initialize the FiFo queue "revFiFo"
 *      fifoIn( &revFiFo , (typeElement)100 ); // push 100 into FiFo queue
 *      fifoOut( &revFiFo , &elem ); // pop 100 from FiFo queue
 */
bool fifoOut(typeFIFO* fifo, typeElement* dat) { 
  if ( (fifo->front==fifo->rear) && (fifo->count==0) )
    return false; // FIFO queue is empty!
  else {
    *dat = fifo->elements[fifo->front]; // pop it from queue
    fifo->front = (fifo->front + 1) % sizeFIFO; // move the pointer
    fifo->count -= 1; // queue number minus one
    return true;
  }
}

#endif // ___ALGORITHM_FIFO_QUEUE_H_