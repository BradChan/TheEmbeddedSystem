#ifndef __CAN_MCP2515_H__
#define __CAN_MCP2515_H__

#include "mcp2515_dfs.h"

#define MAX_CHAR_IN_MESSAGE 8

class MCP_CAN
{
  private:

    byte   __ext_flg; // identifier xxxID, either extended (the 29 LSB) or standard (the 11 LSB)
    unsigned long  __can_id;            // can id
    byte   __dta_len;                   // data length
    byte   __dta[MAX_CHAR_IN_MESSAGE];  // data
    byte   __rtr;                       // rtr
    byte   __pinCS;

  private:
    void mcp2515_reset(void); 
    byte mcp2515_readRegister(const byte address);
    void mcp2515_readRegisterS(const byte address, byte values[], const byte n);
    void mcp2515_setRegister(const byte address, const byte value);
    void mcp2515_setRegisterS(const byte address, const byte values[], const byte n);
    void mcp2515_initCANBuffers(void);
    void mcp2515_modifyRegister(const byte address, const byte mask, const byte data);
    byte mcp2515_readStatus(void);
    byte mcp2515_setCANCTRL_Mode(const byte newmode);
    byte mcp2515_configRate(const byte canSpeed);
    byte mcp2515_init(const byte canSpeed);
    void mcp2515_write_id( const byte mcp_addr, const byte ext, const unsigned long id);
    void mcp2515_read_id( const byte mcp_addr, byte* ext, unsigned long* id);
    void mcp2515_write_canMsg( const byte buffer_sidh_addr, int rtrBit);
    void mcp2515_read_canMsg( const byte buffer_sidh_addr);
    void mcp2515_start_transmit(const byte mcp_addr);
    byte mcp2515_getNextFreeTXBuf(byte *txbuf_n);
    byte setMsg(unsigned long id, byte ext, byte len, byte rtr, byte *pData);
    byte setMsg(unsigned long id, byte ext, byte len, byte *pData);
    byte clearMsg(); 
    byte readMsg(); 
    byte sendMsg(int rtrBit);

  public:
    MCP_CAN(byte _CS);
    byte begin(byte speedset);
    byte init_Mask(byte num, byte ext, unsigned long ulData);
    byte init_Filter(byte num, byte ext, unsigned long ulData);
    byte sendMsgBuf(unsigned long id, byte ext, byte rtr, byte len, byte *buf);
    byte sendMsgBuf(unsigned long id, byte ext, byte len, byte *buf);
    byte readMsgBuf(byte *len, byte *buf);
    byte readMsgBufID(unsigned long *ID, byte *len, byte *buf);
    byte checkReceive(void);
    byte checkError(void);
    unsigned long getCanId(void);
    byte isRemoteRequest(void);
    byte isExtendedFrame(void);
};
#endif  // __CAN_MCP2515_H__
